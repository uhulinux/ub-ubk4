#define _GNU_SOURCE
#define _FILE_OFFSET_BITS 64
#include <unistd.h>
#include <sys/stat.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

int main (int argc, char *argv[])
{
	long long argsize;
	long long newsize;
	char dummy;
	struct stat st;
	int ret=0;

	if (argc < 3)
	{
		fprintf(stderr, "trunc: usage: trunc length file [file...]\n");
		fprintf(stderr, "trunc: if length>0 truncate to length bytes\n");
		fprintf(stderr, "trunc: if length<0 truncate abs(length) bytes from the end\n");
		return 1;
	}
	if (sscanf(argv[1], "%lld%c", &argsize, &dummy) != 1)
	{
		fprintf(stderr, "trunc: invalid length\n");
		return 1;
	}

	while (argc > 2)
	{
		argc--;
		argv++;
		if (stat(argv[1], &st))
		{
			fprintf(stderr, "trunc: stat(%s): %s\n", argv[1], strerror(errno));
			ret=1;
			continue;
		}
		if (!S_ISREG(st.st_mode))
		{
			fprintf(stderr, "trunc: %s: not a regular file\n", argv[1]);
			ret=1;
			continue;
		}
		newsize=argsize;
		if (newsize < 0) newsize+=st.st_size;
		if (newsize > st.st_size)
		{
			fprintf(stderr, "trunc: %s: file size would grow\n", argv[1]);
			ret=1;
			continue;
		}
		if (truncate(argv[1], newsize))
		{
			fprintf(stderr, "trunc: truncate(%s): %s", argv[1], strerror(errno));
			ret=1;
			continue;
		}
	}
	return ret;
}
