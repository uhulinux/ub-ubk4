#!/bin/sh

# This script is only executed if you set switching to "custom" in optimus-manager.conf.
# Everything you write here will be executed by optimus-manager as root prior to loading the nvidia kernel modules.
# Use this to set your own commands for powering up the Nvidia GPU.
