from .envs import VERSION
__version__ = VERSION
