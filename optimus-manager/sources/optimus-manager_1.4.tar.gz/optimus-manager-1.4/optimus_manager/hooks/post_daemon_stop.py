from .. import var


def main():
    var.cleanup_tmp_vars()


if __name__ == "__main__":
    main()
