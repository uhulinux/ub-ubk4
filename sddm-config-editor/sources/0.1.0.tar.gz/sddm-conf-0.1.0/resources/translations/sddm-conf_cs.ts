<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../../src/maindialog.ui" line="40"/>
        <source>Autologin</source>
        <translation>Automatické přihlášení</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="61"/>
        <source>Username for autologin session</source>
        <translation>Uživatelské jméno pro automaticky přihlášené sezení</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="71"/>
        <source>Whether sddm should automatically log back into sessions when they exit</source>
        <translation>Zda se má sddm automaticky přihlásit zpět k sezením po jejich ukončení</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="84"/>
        <source>Name of session file for autologin session (if empty try last logged in)</source>
        <translation>Název souboru se sezením pro automaticky přihlášené sezení (pokud je prázdný, zkusit poslední přihlášení)</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="108"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="135"/>
        <source>Reboot command</source>
        <translation>Příkaz pro restart</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="142"/>
        <source>If property is set to none, numlock won&apos;t be changed
NOTE: Currently ignored if autologin is enabled.</source>
        <translation>Pokud je vlastnost nastavena na žádné, stav numerické klávesnice nebude změněn
POZN.: V současnosti je ignorováno, pokud je zapnuté automatické přihlašování.</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="172"/>
        <source>Initial NumLock state. Can be on, off or none.</source>
        <translation>Počáteční stav zámku klávesnice (NumLock). Může být zapnuta, vypnuta nebo žádný.</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="179"/>
        <source>Input method module</source>
        <translation>Modul metody zadávání</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="186"/>
        <source>Halt command</source>
        <translation>Příkaz pro zastavení</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="207"/>
        <source>Theme</source>
        <translation>Motiv vzhledu</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="250"/>
        <source>Theme directory path</source>
        <translation>Popis umístění složky s motivy vzhledu</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="257"/>
        <source>above which avatars are disabled
unless explicitly enabled with EnableAvatars</source>
        <translation>nad který jsou avataři vypnutí
pokud nejsou výslovně zapnutí pomocí EnableAvatars</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="265"/>
        <source>Current theme name</source>
        <translation>Název stávajícího motivu vzhledu</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="272"/>
        <source>Cursor theme used in the greeter</source>
        <translation>Uživatelsky určený motiv vzhledu uvítací obrazovky</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="279"/>
        <source>Global directory for user avatars</source>
        <translation>Globální složka pro avatary uživatelů</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="289"/>
        <source>Number of users to use as threshold</source>
        <translation>Počet uživatelů, který použít jako práh</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="302"/>
        <source>Preview</source>
        <translation>Náhled</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="309"/>
        <source>Enable display of custom user avatars</source>
        <translation>Zapnout zobrazování uživatelsky určených avatarů uživatelů</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="316"/>
        <source>The files should be named &lt;username&gt;.face.icon</source>
        <translation>Soubory by měly mít názvy &lt;username&gt;.face.icon</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="324"/>
        <source>Users</source>
        <translation>Uživatelé</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="345"/>
        <source>Default $PATH for logged in users</source>
        <translation>Výchozí obsah proměnné $PATH pro přihlašující se uživatele</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="355"/>
        <source>Comma-separated list of shells</source>
        <translation>Čárkami oddělovaný seznam shellů</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="365"/>
        <source>Comma-separated list of users that should not be listed</source>
        <translation>Čárkou oddělovaný seznam uživatelů, kteří nebudou vypsáni</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="375"/>
        <source>Minimum user id for displayed users</source>
        <translation>Nejnižší identif. uživatele pro zobrazované uživatele</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="392"/>
        <source>Maximum user id for displayed users</source>
        <translation>Nejvyšší identif. uživatele pro zobrazované uživatele</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="409"/>
        <source>Remember the session of the last successfully logged in user</source>
        <translation>Pamatovat si relaci naposledy úspěšně přihlášeného uživatele</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="416"/>
        <source>Remember the last successfully logged in user</source>
        <translation>Pamatovat si naposledy úspěšně přihlášeného uživatele</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="424"/>
        <source>Wayland</source>
        <translation>Wayland</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="445"/>
        <location filename="../../src/maindialog.ui" line="565"/>
        <source>Enable Qt&apos;s automatic high-DPI scaling</source>
        <translation>Zapnout automatické škálování HDPI v rámci Qt</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="452"/>
        <location filename="../../src/maindialog.ui" line="676"/>
        <source>Path to a script to execute when starting the desktop session</source>
        <translation>Popis umístění skriptu který vykonat při spouštění relace plochy</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="470"/>
        <location filename="../../src/maindialog.ui" line="740"/>
        <source>Path to the user session log file</source>
        <translation>Popis umístění souboru se záznamem událostí relace uživatele</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="488"/>
        <source>Directory containing available Wayland sessions</source>
        <translation>Složka obsahující Wayland relace, které jsou k dispozici</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="520"/>
        <source>X11</source>
        <translation>X11</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="572"/>
        <source>The lowest virtual terminal number that will be used</source>
        <translation>Nejnižší číslo virtuálního terminálu, který bude použit</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="669"/>
        <source>Path to X server binary</source>
        <translation>Popis umístění spustitelného souboru s X serverem</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="683"/>
        <source>Arguments passed to the X server invocation</source>
        <translation>Argumenty předané vyvolání X serveru</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="690"/>
        <source>Directory containing available X sessions</source>
        <translation>Složka obsahující X relace k dispozici</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="697"/>
        <source>Path to a script to execute when starting the display server</source>
        <translation>Popis umístění skriptu který vykonat při spouštění zobrazovacího serveru</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="704"/>
        <source>Path to a script to execute when stopping the display server</source>
        <translation>Popis umístění skriptu který vykonat při zastavování zobrazovacího serveru</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="714"/>
        <source>Path to xauth binary</source>
        <translation>Popis umístění spouštěcího souboru s xauth</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="721"/>
        <source>Path to Xephyr binary</source>
        <translation>Popis umístění spouštěcího souboru s Xephyr</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="747"/>
        <source>Path to the Xauthority file</source>
        <translation>Popis umístění souboru Xauthority</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="759"/>
        <source>File</source>
        <translation>Soubor</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="778"/>
        <source>About</source>
        <translation>O aplikaci</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="23"/>
        <source>SDDM Configuration Editor</source>
        <translation>Editor nastavení pro SDDM</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="61"/>
        <source>SDDM Conf v</source>
        <translation>SSDM nast. v</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="62"/>
        <source>Copyright (C) 2021
Andrea Zanellato &lt;redtid3@gmail.com&gt;</source>
        <translation>Autorská práva © 2021
Andrea Zanellato &lt;redtid3@gmail.com&gt;</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="72"/>
        <source>Close %1 preview</source>
        <translation>Zavřít náhled %1</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="87"/>
        <source>Choose a file</source>
        <translation>Zvolte soubor</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="94"/>
        <source>Choose a directory</source>
        <translation>Zvolte složku</translation>
    </message>
</context>
</TS>
