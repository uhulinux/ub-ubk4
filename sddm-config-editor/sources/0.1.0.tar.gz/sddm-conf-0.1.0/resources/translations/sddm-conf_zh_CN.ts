<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../../src/maindialog.ui" line="40"/>
        <source>Autologin</source>
        <translation>自动登录</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="61"/>
        <source>Username for autologin session</source>
        <translation>自动登录会话的用户名</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="71"/>
        <source>Whether sddm should automatically log back into sessions when they exit</source>
        <translation>sddm 是否应在会话退出时自动重新登录到会话</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="84"/>
        <source>Name of session file for autologin session (if empty try last logged in)</source>
        <translation>自动登录会话的会话文件名称（如果留空，则尝试使用上次登录时的）</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="108"/>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="135"/>
        <source>Reboot command</source>
        <translation>重启命令</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="142"/>
        <source>If property is set to none, numlock won&apos;t be changed
NOTE: Currently ignored if autologin is enabled.</source>
        <translation>如果属性设置为无，则不会更改 numlock状态
注意：如果启用了自动登录，则当前被忽略。</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="172"/>
        <source>Initial NumLock state. Can be on, off or none.</source>
        <translation>初始的数字键盘锁定状态。可以是打开，关闭或者空。</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="179"/>
        <source>Input method module</source>
        <translation>输入法模块</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="186"/>
        <source>Halt command</source>
        <translation>关机命令</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="207"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="250"/>
        <source>Theme directory path</source>
        <translation>主题目录</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="257"/>
        <source>above which avatars are disabled
unless explicitly enabled with EnableAvatars</source>
        <translation>以上是禁用的头像
除非显式启用使用EnableAvatars启用</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="265"/>
        <source>Current theme name</source>
        <translation>当前主题名</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="272"/>
        <source>Cursor theme used in the greeter</source>
        <translation>greeter 中使用的游标主题</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="279"/>
        <source>Global directory for user avatars</source>
        <translation>用户图标的全局目录</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="289"/>
        <source>Number of users to use as threshold</source>
        <translation>要用作阈值的用户数</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="302"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="309"/>
        <source>Enable display of custom user avatars</source>
        <translation>启用自定义用户化的显示</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="316"/>
        <source>The files should be named &lt;username&gt;.face.icon</source>
        <translation>这个文件应该命名为 &lt;username&gt;.face.icon</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="324"/>
        <source>Users</source>
        <translation>用户</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="345"/>
        <source>Default $PATH for logged in users</source>
        <translation>已登录用户的默认 $PATH</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="355"/>
        <source>Comma-separated list of shells</source>
        <translation>以逗号分隔的列表</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="365"/>
        <source>Comma-separated list of users that should not be listed</source>
        <translation>不应该被列出的用逗号分隔的用户列表</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="375"/>
        <source>Minimum user id for displayed users</source>
        <translation>显示用户的最小用户 id</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="392"/>
        <source>Maximum user id for displayed users</source>
        <translation>显示用户的最大用户 id</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="409"/>
        <source>Remember the session of the last successfully logged in user</source>
        <translation>记住上次成功登录的用户的桌面</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="416"/>
        <source>Remember the last successfully logged in user</source>
        <translation>记住上次成功登录的用户</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="424"/>
        <source>Wayland</source>
        <translation>Wayland</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="445"/>
        <location filename="../../src/maindialog.ui" line="565"/>
        <source>Enable Qt&apos;s automatic high-DPI scaling</source>
        <translation>启用 Qt的高分辨率自动缩放功能</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="452"/>
        <location filename="../../src/maindialog.ui" line="676"/>
        <source>Path to a script to execute when starting the desktop session</source>
        <translation>启动桌面会话时要执行的脚本路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="470"/>
        <location filename="../../src/maindialog.ui" line="740"/>
        <source>Path to the user session log file</source>
        <translation>用户的会话日志文件路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="488"/>
        <source>Directory containing available Wayland sessions</source>
        <translation>包含有效Wayland会话的目录</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="520"/>
        <source>X11</source>
        <translation>X11</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="572"/>
        <source>The lowest virtual terminal number that will be used</source>
        <translation>将被使用的最低虚拟终端号码</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="669"/>
        <source>Path to X server binary</source>
        <translation>X 服务器二进制的路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="683"/>
        <source>Arguments passed to the X server invocation</source>
        <translation>传递给 X 服务器调用的参数</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="690"/>
        <source>Directory containing available X sessions</source>
        <translation>包含可用 X 会话的目录</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="697"/>
        <source>Path to a script to execute when starting the display server</source>
        <translation>当启动显示服务时要执行的脚本的路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="704"/>
        <source>Path to a script to execute when stopping the display server</source>
        <translation>当停止显示服务时要执行的脚本的路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="714"/>
        <source>Path to xauth binary</source>
        <translation>X 的授权二进制路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="721"/>
        <source>Path to Xephyr binary</source>
        <translation>Xephyr的二进制文件路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="747"/>
        <source>Path to the Xauthority file</source>
        <translation>X 的授权文件路径</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="759"/>
        <source>File</source>
        <translation>设置文件</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.ui" line="778"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="23"/>
        <source>SDDM Configuration Editor</source>
        <translation>SDDM 设置工具</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="61"/>
        <source>SDDM Conf v</source>
        <translation>SDDM Conf v</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="62"/>
        <source>Copyright (C) 2021
Andrea Zanellato &lt;redtid3@gmail.com&gt;</source>
        <translation>版权声明 (C) 2021
Andrea Zanellato &lt;redtid3@gmail.com&gt;</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="72"/>
        <source>Close %1 preview</source>
        <translation>关闭%1预览</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="87"/>
        <source>Choose a file</source>
        <translation>选择文件</translation>
    </message>
    <message>
        <location filename="../../src/maindialog.cpp" line="94"/>
        <source>Choose a directory</source>
        <translation>选择目录</translation>
    </message>
</context>
</TS>
